function toggleMenu() {
    const toggleMenu = document.querySelector('.toggleMenu');
    const navigation = document.querySelector('.navbar-nav');
    toggleMenu.classList.toggle('active');
    navigation.classList.toggle('active');
}
